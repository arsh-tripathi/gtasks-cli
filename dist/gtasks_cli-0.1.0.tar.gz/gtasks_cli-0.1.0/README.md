# gtasks-cli

A Command line interface for interacting with google tasks using the google api

## Installation

1. Clone the repo
